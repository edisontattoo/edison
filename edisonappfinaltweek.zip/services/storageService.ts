import { ReleaseFormData } from '../types';

// The key used to store all release form submissions in localStorage.
const FORMS_STORAGE_KEY = 'app_release_forms';

// Helper function to get all forms from localStorage.
const getFormsFromStorage = (): ReleaseFormData[] => {
    try {
        const storedData = localStorage.getItem(FORMS_STORAGE_KEY);
        return storedData ? JSON.parse(storedData) : [];
    } catch (error) {
        console.error("Error parsing release forms from localStorage:", error);
        // If parsing fails, return an empty array to prevent app crash.
        return [];
    }
};

// Helper function to save all forms to localStorage.
const saveFormsToStorage = (forms: ReleaseFormData[]): void => {
    try {
        localStorage.setItem(FORMS_STORAGE_KEY, JSON.stringify(forms));
    } catch (error) {
        console.error("Error saving release forms to localStorage:", error);
    }
};

/**
 * Saves a new release form to the browser's localStorage.
 * This is a frontend-only solution. No backend is involved.
 * @param formData The form data to save, without an ID.
 * @returns The newly created form data, including its assigned ID.
 */
export const saveReleaseForm = async (formData: Omit<ReleaseFormData, 'id'>): Promise<ReleaseFormData> => {
    return new Promise((resolve) => {
        const allForms = getFormsFromStorage();
        // Generate a unique ID for the form entry
        const newId = `form_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        // The complete form data includes the generated ID.
        const newForm: ReleaseFormData = {
            ...formData,
            id: newId,
        };
        
        // Add the new form to the beginning of the list for easy access to the latest.
        allForms.unshift(newForm);
        
        // Save the updated list back to localStorage.
        saveFormsToStorage(allForms);
        
        // Resolve the promise with the newly created form.
        resolve(newForm);
    });
};


/**
 * Retrieves a single release form by its ID from localStorage.
 * @param id The unique identifier of the form.
 * @returns The form data, or null if not found.
 */
export const getReleaseFormById = async (id: string): Promise<ReleaseFormData | null> => {
    return new Promise((resolve) => {
        const allForms = getFormsFromStorage();
        const foundForm = allForms.find(form => form.id === id);
        resolve(foundForm || null);
    });
};

/**
 * Retrieves a list of all saved forms from localStorage.
 * @returns An array of all form data.
 */
export const getAllReleaseForms = async (): Promise<ReleaseFormData[]> => {
     return new Promise((resolve) => {
        const allForms = getFormsFromStorage();
        resolve(allForms);
    });
};
